import grpc
import time
from concurrent import futures
import sys
import os

# Add generated protobufs to path or assume they are compiled in same dir
# Note: User must run `python -m grpc_tools.protoc -Iapp/src/main/proto --python_out=. --grpc_python_out=. app/src/main/proto/speculative.proto`

import speculative_pb2
import speculative_pb2_grpc

class SpeculativeDecoderServicer(speculative_pb2_grpc.SpeculativeDecoderServicer):
    def VerifyDraft(self, request, context):
        print(f"Received verification request: Session {request.session_id}")
        print(f"Draft tokens: {request.draft_token_ids}")
        
        # Simulate some processing delay
        time.sleep(0.05) 
        
        # Mocking an acceptance rate of ~75%
        accepted = max(1, len(request.draft_token_ids) - 1)
        acceptance_rate = accepted / len(request.draft_token_ids) if request.draft_token_ids else 1.0
        
        response = speculative_pb2.VerifyResponse(
            accepted_count=accepted,
            authoritative_token=1234,  # mock next token
            new_window_size=request.draft_token_ids, # will be overridden based on client 
            acceptance_rate=acceptance_rate,
            fallback_mode=False
        )
        return response

def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    speculative_pb2_grpc.add_SpeculativeDecoderServicer_to_server(
        SpeculativeDecoderServicer(), server
    )
    server.add_insecure_port('[::]:50051')
    server.start()
    print("Mock Speculative Decoder Server started on port 50051...")
    server.wait_for_termination()

if __name__ == '__main__':
    serve()
