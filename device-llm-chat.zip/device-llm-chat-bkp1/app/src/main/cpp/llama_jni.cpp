#include <android/log.h>
#include <chrono>
#include <jni.h>
#include <string>
#include <vector>
// Make sure llama.h is in path
#include "llama.h"

#define LOG_TAG "DeviceLLmChat"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

struct AppState {
  llama_model *model = nullptr;
  llama_context *ctx = nullptr;
  llama_batch batch;
  bool generating = false;
  bool stop_flag = false;

  ~AppState() {
    if (ctx)
      llama_free(ctx);
    if (model)
      llama_model_free(model);
    llama_batch_free(batch);
  }
};

static AppState *g_state = nullptr;

extern "C" JNIEXPORT jboolean JNICALL
Java_com_devicellm_chat_engine_LlamaEngine_loadModelJNI(
    JNIEnv *env, jobject thiz, jstring pathStr, jint contextSize,
    jint threadCount, jboolean useNnapi) {
  if (g_state) {
    delete g_state;
    g_state = nullptr;
  }

  const char *model_path = env->GetStringUTFChars(pathStr, nullptr);
  LOGI("Loading model %s, NNAPI: %d", model_path, useNnapi);

  llama_backend_init();

  auto mparams = llama_model_default_params();
  if (useNnapi) {
    mparams.n_gpu_layers = 99; // Offload fully to NNAPI if available
  }

  llama_model *model = llama_load_model_from_file(model_path, mparams);
  env->ReleaseStringUTFChars(pathStr, model_path);

  if (!model) {
    LOGE("Could not load model");
    return JNI_FALSE;
  }

  auto cparams = llama_context_default_params();
  cparams.n_ctx = contextSize;
  cparams.n_threads = threadCount;
  cparams.n_threads_batch = threadCount;

  llama_context *ctx = llama_new_context_with_model(model, cparams);
  if (!ctx) {
    LOGE("Could not create context");
    llama_model_free(model);
    return JNI_FALSE;
  }

  g_state = new AppState();
  g_state->model = model;
  g_state->ctx = ctx;
  g_state->batch = llama_batch_init(contextSize, 0, 1);

  LOGI("Successfully loaded model");
  return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_devicellm_chat_engine_LlamaEngine_stopGenerationJNI(JNIEnv *env,
                                                             jobject thiz) {
  if (g_state)
    g_state->stop_flag = true;
}

extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_devicellm_chat_engine_LlamaEngine_generateJNI(
    JNIEnv *env, jobject thiz, jstring prompt, jobject callback, jint maxTokens,
    jfloat temperature, jfloat top_p) {
  if (!g_state || !g_state->ctx)
    return nullptr;

  g_state->generating = true;
  g_state->stop_flag = false;

  const char *pStr = env->GetStringUTFChars(prompt, nullptr);
  std::string promptStr(pStr);
  env->ReleaseStringUTFChars(prompt, pStr);

  jclass callbackClass = env->GetObjectClass(callback);
  jmethodID onTokenMethod = env->GetMethodID(
      callbackClass, "invoke",
      "(Ljava/lang/Object;)Ljava/lang/Object;"); // Function1 invoke

  auto start_time = std::chrono::high_resolution_clock::now();
  float ttft = 0.0f;

  const struct llama_vocab *vocab = llama_model_get_vocab(g_state->model);
  std::vector<llama_token> tokens(promptStr.length() + 4);
  int n_tokens = llama_tokenize(vocab, promptStr.c_str(), promptStr.length(),
                                tokens.data(), tokens.size(), true, true);
  if (n_tokens < 0) {
    tokens.resize(-n_tokens);
    n_tokens = llama_tokenize(vocab, promptStr.c_str(), promptStr.length(),
                              tokens.data(), tokens.size(), true, true);
  }
  tokens.resize(n_tokens);

  llama_memory_clear(llama_get_memory(g_state->ctx), false);

  g_state->batch.n_tokens = 0;
  for (int i = 0; i < n_tokens; i++) {
    g_state->batch.token[g_state->batch.n_tokens] = tokens[i];
    g_state->batch.pos[g_state->batch.n_tokens] = i;
    g_state->batch.n_seq_id[g_state->batch.n_tokens] = 1;
    g_state->batch.seq_id[g_state->batch.n_tokens][0] = 0;
    g_state->batch.logits[g_state->batch.n_tokens] = false;
    g_state->batch.n_tokens++;
  }
  g_state->batch.logits[g_state->batch.n_tokens - 1] = true;

  if (llama_decode(g_state->ctx, g_state->batch) != 0) {
    LOGE("Prompt decoding failed");
    g_state->generating = false;
    return nullptr;
  }

  int n_cur = g_state->batch.n_tokens;
  int generated_tokens = 0;

  auto ttft_time = std::chrono::high_resolution_clock::now();
  ttft =
      std::chrono::duration<float, std::milli>(ttft_time - start_time).count();

  while (n_cur <= n_tokens + maxTokens && !g_state->stop_flag) {

    llama_sampler_chain_params sparams;
    sparams.no_perf = false;
    struct llama_sampler *smpl = llama_sampler_chain_init(sparams);
    llama_sampler_chain_add(smpl, llama_sampler_init_top_p(top_p, 1));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(temperature));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    llama_token next_token = llama_sampler_sample(smpl, g_state->ctx, -1);
    llama_sampler_free(smpl);

    if (llama_vocab_is_eog(vocab, next_token)) {
      break;
    }

    char buf[128];
    int n_len =
        llama_token_to_piece(vocab, next_token, buf, sizeof(buf), 0, true);
    if (n_len > 0) {
      std::string piece(buf, n_len);
      jstring jPiece = env->NewStringUTF(piece.c_str());
      env->CallObjectMethod(callback, onTokenMethod, jPiece);
      env->DeleteLocalRef(jPiece);
    }

    g_state->batch.n_tokens = 0;
    g_state->batch.token[g_state->batch.n_tokens] = next_token;
    g_state->batch.pos[g_state->batch.n_tokens] = n_cur;
    g_state->batch.n_seq_id[g_state->batch.n_tokens] = 1;
    g_state->batch.seq_id[g_state->batch.n_tokens][0] = 0;
    g_state->batch.logits[g_state->batch.n_tokens] = true;
    g_state->batch.n_tokens++;

    if (llama_decode(g_state->ctx, g_state->batch) != 0) {
      LOGE("Token decoding failed");
      break;
    }

    n_cur++;
    generated_tokens++;
  }

  auto end_time = std::chrono::high_resolution_clock::now();
  float total_time =
      std::chrono::duration<float, std::milli>(end_time - start_time).count();
  float tokens_per_sec = generated_tokens / (total_time / 1000.0f);

  jfloatArray result = env->NewFloatArray(4);
  float metrics[4] = {ttft, total_time, tokens_per_sec,
                      (float)generated_tokens};
  env->SetFloatArrayRegion(result, 0, 4, metrics);

  g_state->generating = false;
  return result;
}

extern "C" JNIEXPORT void JNICALL
Java_com_devicellm_chat_engine_LlamaEngine_freeModelJNI(JNIEnv *env,
                                                        jobject thiz) {
  if (g_state) {
    delete g_state;
    g_state = nullptr;
  }
  llama_backend_free();
}
