package com.devicellm.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.devicellm.chat.domain.GenerationMetrics
import com.devicellm.chat.domain.GenerationMode
import com.devicellm.chat.engine.GrpcVerifier
import com.devicellm.chat.engine.LlamaEngine
import com.devicellm.chat.engine.SpeculativeEngine
import com.devicellm.chat.ui.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay

class ChatViewModel : ViewModel() {
    private val llamaEngine = LlamaEngine()
    private val grpcVerifier = GrpcVerifier()
    private val speculativeEngine = SpeculativeEngine(llamaEngine, grpcVerifier)

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _currentMode = MutableStateFlow(GenerationMode.CPU)
    val currentMode: StateFlow<GenerationMode> = _currentMode.asStateFlow()

    private val _metrics = MutableStateFlow<GenerationMetrics?>(null)
    val metrics: StateFlow<GenerationMetrics?> = _metrics.asStateFlow()

    private val _isModelLoaded = MutableStateFlow(false)
    val isModelLoaded: StateFlow<Boolean> = _isModelLoaded.asStateFlow()

    // Settings State
    val temperature = MutableStateFlow(0.7f)
    val topP = MutableStateFlow(0.9f)
    val maxTokens = MutableStateFlow(512f)
    val draftWindowSize = MutableStateFlow(5f)
    val serverAddress = MutableStateFlow("10.0.2.2:50051")
    
    // Model Path tracking
    private var currentModelPath = ""

    fun initModel(modelPath: String, useNnapi: Boolean) {
        currentModelPath = modelPath
        viewModelScope.launch {
            val loaded = withContext(Dispatchers.IO) {
                // To avoid blocking the UI, JNI intialization goes to background
                llamaEngine.loadModel(
                    modelPath = modelPath,
                    contextSize = 2048,
                    threadCount = 4,   // Typically 4 threads for mobile CPU
                    useNnapi = useNnapi
                )
            }
            _isModelLoaded.value = loaded
        }
    }

    fun setMode(mode: GenerationMode) {
        _currentMode.value = mode
        if (currentModelPath.isNotEmpty() && (mode == GenerationMode.CPU || mode == GenerationMode.NPU)) {
            // Re-initialize model to switch backends
            initModel(currentModelPath, useNnapi = mode == GenerationMode.NPU)
        }
    }

    fun updateServerAddress(address: String) {
        serverAddress.value = address
        val parts = address.split(":")
        if (parts.size == 2) {
            grpcVerifier.updateServerMetrics(parts[0], parts[1].toIntOrNull() ?: 50051)
        }
    }

    fun sendMessage(prompt: String) {
        if (!_isModelLoaded.value) return

        val userMsg = ChatMessage(prompt, isUser = true)
        _messages.value = _messages.value + userMsg

        _isGenerating.value = true
        // Allow old metrics to remain visible until new ones are ready

        val structuredPrompt = "User: $prompt\nBot:"

        if (_currentMode.value == GenerationMode.HYBRID_SPECULATIVE) {
            viewModelScope.launch {
                val botMsg = ChatMessage("", isUser = false, isGenerating = true)
                var currentText = ""
                _messages.value = _messages.value + botMsg

                speculativeEngine.generateHybrid(
                    prompt = structuredPrompt,
                    maxTokens = maxTokens.value.toInt(),
                    temperature = temperature.value,
                    topP = topP.value,
                    initialWindowSize = draftWindowSize.value.toInt()
                ).collect { (text, metric) ->
                    currentText += text
                    
                    // Throttling UI updates
                    withContext(Dispatchers.Main) {
                        _messages.value = _messages.value.dropLast(1) + botMsg.copy(text = currentText)
                        _metrics.value = metric
                    }
                }
                
                withContext(Dispatchers.Main) {
                    _messages.value = _messages.value.dropLast(1) + botMsg.copy(text = currentText, isGenerating = false)
                    _isGenerating.value = false
                }
            }
        } else {
            // CPU / NPU modes
            viewModelScope.launch(Dispatchers.IO) {
                var currentText = ""
                
                withContext(Dispatchers.Main) {
                    _messages.value = _messages.value + ChatMessage("", isUser = false, isGenerating = true)
                }

                var lastUpdateTime = System.currentTimeMillis()
                
                val finalMetrics = llamaEngine.generate(
                    prompt = structuredPrompt,
                    maxTokens = maxTokens.value.toInt(),
                    temperature = temperature.value,
                    topP = topP.value
                ) { token ->
                    currentText += token
                    val now = System.currentTimeMillis()
                    // Update UI at most every 50ms for smooth scrolling and performance
                    if (now - lastUpdateTime > 50) {
                        lastUpdateTime = now
                        val updatedMsg = ChatMessage(currentText, isUser = false, isGenerating = true)
                        viewModelScope.launch(Dispatchers.Main) {
                            val newList = _messages.value.toMutableList()
                            newList[newList.size - 1] = updatedMsg
                            _messages.value = newList
                        }
                    }
                }

                withContext(Dispatchers.Main) {
                    val finalMsg = ChatMessage(currentText, isUser = false, isGenerating = false)
                    val newList = _messages.value.toMutableList()
                    newList[newList.size - 1] = finalMsg
                    _messages.value = newList
                    _metrics.value = finalMetrics
                    _isGenerating.value = false
                }
            }
        }
    }

    fun stopGeneration() {
        if (_isGenerating.value) {
            llamaEngine.stop()
            speculativeEngine.stop()
        }
    }

    override fun onCleared() {
        super.onCleared()
        llamaEngine.free()
        grpcVerifier.shutdown()
    }
}
