package com.devicellm.chat.domain

enum class GenerationMode(val displayName: String) {
    CPU("CPU (llama.cpp)"),
    NPU("NPU (NNAPI Fast)"),
    HYBRID_SPECULATIVE("Hybrid Speculative (CPU + Remote)")
}
