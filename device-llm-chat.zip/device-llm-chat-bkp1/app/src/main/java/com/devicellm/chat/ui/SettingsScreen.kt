package com.devicellm.chat.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(
    temperature: Float,
    onTemperatureChange: (Float) -> Unit,
    topP: Float,
    onTopPChange: (Float) -> Unit,
    maxTokens: Float,
    onMaxTokensChange: (Float) -> Unit,
    draftWindowSize: Float,
    onDraftWindowSizeChange: (Float) -> Unit,
    serverAddress: String,
    onServerAddressChange: (String) -> Unit
) {
    Column(modifier = Modifier.padding(16.dp).fillMaxWidth()) {
        Text("Hyperparameters", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        
        Text("Temperature: ${String.format("%.2f", temperature)}")
        Slider(value = temperature, onValueChange = onTemperatureChange, valueRange = 0f..2f)

        Text("Top P: ${String.format("%.2f", topP)}")
        Slider(value = topP, onValueChange = onTopPChange, valueRange = 0f..1f)

        Text("Max Tokens: ${maxTokens.toInt()}")
        Slider(value = maxTokens, onValueChange = onMaxTokensChange, valueRange = 10f..2048f)

        Spacer(modifier = Modifier.height(16.dp))
        Text("Hybrid Backend Settings", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))

        Text("Draft Window Size: ${draftWindowSize.toInt()}")
        Slider(value = draftWindowSize, onValueChange = onDraftWindowSizeChange, valueRange = 1f..32f)

        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = serverAddress,
            onValueChange = onServerAddressChange,
            label = { Text("Server Address (IP:Port)") },
            modifier = Modifier.fillMaxWidth()
        )
    }
}
