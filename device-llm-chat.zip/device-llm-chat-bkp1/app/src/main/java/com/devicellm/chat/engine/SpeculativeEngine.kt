package com.devicellm.chat.engine

import com.devicellm.chat.domain.GenerationMetrics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class SpeculativeEngine(
    private val llamaEngine: LlamaEngine,
    private val grpcVerifier: GrpcVerifier
) {
    private var stopRequested = false

    fun stop() {
        stopRequested = true
        llamaEngine.stop()
    }

    /**
     * Executes hybrid speculative decoding flow.
     * Emits the generated text piece and the latest metrics inline.
     */
    fun generateHybrid(
        prompt: String,
        maxTokens: Int = 512,
        temperature: Float = 0.7f,
        topP: Float = 0.9f,
        initialWindowSize: Int = 5
    ): Flow<Pair<String, GenerationMetrics>> = flow {
        stopRequested = false
        var currentPrompt = prompt
        var windowSize = initialWindowSize
        var totalTokensGenerated = 0
        var tokensThisSession = 0
        val startTime = System.currentTimeMillis()
        var ttft = 0f

        while (totalTokensGenerated < maxTokens && !stopRequested) {
            val draftTokensStr = StringBuilder()
            val draftTokenIds = mutableListOf<Int>() // Simulated IDs for MVP
            
            // 1) Draft model generates N draft tokens
            val sessionStartTime = System.currentTimeMillis()
            llamaEngine.generate(
                prompt = currentPrompt,
                maxTokens = windowSize,
                temperature = temperature,
                topP = topP
            ) { token ->
                draftTokensStr.append(token)
                draftTokenIds.add(token.hashCode()) // Mocking token ID
            }

            if (stopRequested) break

            val rttStart = System.currentTimeMillis()
            // 2) Verify with authoritative remote model
            val verification = grpcVerifier.verifyDraft(
                prompt = currentPrompt,
                draftTokens = draftTokenIds,
                rttMs = 0f
            )
            val rttMs = (System.currentTimeMillis() - rttStart).toFloat()

            if (ttft == 0f) {
                ttft = (System.currentTimeMillis() - startTime).toFloat()
            }

            if (verification != null && !verification.fallbackMode) {
                // 3) Apply corrections
                windowSize = verification.newWindowSize
                val acceptedCount = verification.acceptedCount
                
                // Adaptive window sizing based on requirement:
                // If acceptance_rate < 0.6 reduce window, if > 0.8 increase
                if (verification.acceptanceRate < 0.6f) {
                    windowSize = maxOf(1, windowSize - 1)
                } else if (verification.acceptanceRate > 0.8f) {
                    windowSize = minOf(15, windowSize + 2)
                }

                // Append accepted text to prompt context
                // In production, we'd adjust the KV cache natively.
                val acceptedText = draftTokensStr.toString() // Simulated accepted text
                currentPrompt += acceptedText
                tokensThisSession += acceptedCount

                val metrics = GenerationMetrics(
                    ttftMs = ttft,
                    totalTimeMs = (System.currentTimeMillis() - startTime).toFloat(),
                    tokensPerSec = tokensThisSession / ((System.currentTimeMillis() - startTime) / 1000f),
                    totalTokens = tokensThisSession,
                    draftWindowSize = windowSize,
                    acceptanceRate = verification.acceptanceRate,
                    rttMs = rttMs,
                    fallbackMode = false
                )
                emit(Pair(acceptedText, metrics))
            } else {
                // Server unavailable or fallback mode, gracefully degrade to CPU mode
                var fallbackStr = ""
                llamaEngine.generate(
                    prompt = currentPrompt,
                    maxTokens = maxTokens - totalTokensGenerated,
                    temperature = temperature,
                    topP = topP
                ) { token ->
                    fallbackStr += token
                    tokensThisSession++
                }
                val metrics = GenerationMetrics(
                    ttftMs = ttft,
                    totalTimeMs = (System.currentTimeMillis() - startTime).toFloat(),
                    tokensPerSec = tokensThisSession / ((System.currentTimeMillis() - startTime) / 1000f),
                    totalTokens = tokensThisSession,
                    draftWindowSize = windowSize,
                    acceptanceRate = 0f,
                    rttMs = rttMs,
                    fallbackMode = true
                )
                emit(Pair(fallbackStr, metrics))
                break
            }
            totalTokensGenerated += tokensThisSession
        }
    }.flowOn(Dispatchers.IO)
}
