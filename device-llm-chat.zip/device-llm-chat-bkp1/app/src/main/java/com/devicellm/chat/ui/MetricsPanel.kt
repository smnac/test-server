package com.devicellm.chat.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.devicellm.chat.domain.GenerationMetrics

@Composable
fun MetricsPanel(metrics: GenerationMetrics, modifier: Modifier = Modifier) {
    ElevatedCard(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                "⏱ TTFT: ${String.format("%.2f", metrics.ttftMs)} ms   |   ⚡ ${String.format("%.2f", metrics.tokensPerSec)} tok/s",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "📊 Total: ${metrics.totalTokens} tokens in ${String.format("%.2f", metrics.totalTimeMs)} ms",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (metrics.draftWindowSize > 0) {
                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Draft Window: ${metrics.draftWindowSize}", style = MaterialTheme.typography.labelMedium)
                    Text("Acc Rate: ${String.format("%.2f", metrics.acceptanceRate)}", style = MaterialTheme.typography.labelMedium)
                    Text("RTT: ${metrics.rttMs} ms", style = MaterialTheme.typography.labelMedium)
                }
                if (metrics.fallbackMode) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("⚠️ CPU Fallback Mode Active", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}
