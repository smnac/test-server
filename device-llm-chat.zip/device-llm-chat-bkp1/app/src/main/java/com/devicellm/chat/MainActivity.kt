package com.devicellm.chat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.devicellm.chat.domain.GenerationMode
import com.devicellm.chat.ui.ChatScreen
import com.devicellm.chat.ui.MetricsPanel
import com.devicellm.chat.ui.ModeSelector
import com.devicellm.chat.ui.SettingsScreen
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

class MainActivity : ComponentActivity() {
    private val viewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Assumes user pushes a GGUF to the app's files dir
        val modelPath = File(filesDir, "tinyllama.gguf").absolutePath
        
        // Try copying from assets if it doesn't exist AND we actually have it in assets
        if (!File(modelPath).exists()) {
            try {
                if (assets.list("")?.contains("tinyllama.gguf") == true) {
                    copyModelFromAssets("tinyllama.gguf", modelPath)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        
        if (File(modelPath).exists()) {
            viewModel.initModel(modelPath, useNnapi = false)
        }

        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen(viewModel)
                }
            }
        }
    }

    private fun copyModelFromAssets(assetName: String, destPath: String) {
        try {
            val inputStream: InputStream = assets.open(assetName)
            val outputStream = FileOutputStream(destPath)
            val buffer = ByteArray(4 * 1024)
            var read: Int
            while (inputStream.read(buffer).also { read = it } != -1) {
                outputStream.write(buffer, 0, read)
            }
            outputStream.flush()
            outputStream.close()
            inputStream.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

@Composable
fun MainScreen(viewModel: ChatViewModel) {
    val messages by viewModel.messages.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val currentMode by viewModel.currentMode.collectAsState()
    val metrics by viewModel.metrics.collectAsState()
    val isModelLoaded by viewModel.isModelLoaded.collectAsState()

    val temperature by viewModel.temperature.collectAsState()
    val topP by viewModel.topP.collectAsState()
    val maxTokens by viewModel.maxTokens.collectAsState()
    val draftWindow by viewModel.draftWindowSize.collectAsState()
    val address by viewModel.serverAddress.collectAsState()

    var showSettings by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                ModeSelector(
                    currentMode = currentMode,
                    onModeSelected = { mode -> 
                        viewModel.setMode(mode) 
                    },
                    modifier = Modifier.width(250.dp)
                )
            },
            actions = {
                TextButton(onClick = { showSettings = !showSettings }) {
                    Text("Settings")
                }
            }
        )

        // We look for the existence of the model right now for MVP dynamically
        val isModelFilePresent = remember { mutableStateOf(false) }
        LaunchedEffect(Unit) {
            isModelFilePresent.value = File("/data/user/0/com.devicellm.chat/files/tinyllama.gguf").exists()
        }

        if (!isModelLoaded && !isModelFilePresent.value) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            Text(
                "Loading Local Model...\n(Please push a model to /data/user/0/com.devicellm.chat/files/tinyllama.gguf via adb)", 
                modifier = Modifier.padding(8.dp)
            )
        }

        if (showSettings) {
            SettingsScreen(
                temperature = temperature,
                onTemperatureChange = { viewModel.temperature.value = it },
                topP = topP,
                onTopPChange = { viewModel.topP.value = it },
                maxTokens = maxTokens,
                onMaxTokensChange = { viewModel.maxTokens.value = it },
                draftWindowSize = draftWindow,
                onDraftWindowSizeChange = { viewModel.draftWindowSize.value = it },
                serverAddress = address,
                onServerAddressChange = { viewModel.updateServerAddress(it) }
            )
        } else {
            // Metrics Panel
            metrics?.let {
                MetricsPanel(metrics = it)
            }

            // Chat Interface
            ChatScreen(
                messages = messages,
                isGenerating = isGenerating,
                onSendMessage = { prompt -> viewModel.sendMessage(prompt) },
                onStopGeneration = { viewModel.stopGeneration() },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun TopAppBar(
    title: @Composable () -> Unit,
    actions: @Composable RowScope.() -> Unit
) {
    Surface(shadowElevation = 2.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            title()
            Row { actions() }
        }
    }
}
