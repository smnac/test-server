package com.devicellm.chat.domain

data class GenerationMetrics(
    val ttftMs: Float = 0f,
    val totalTimeMs: Float = 0f,
    val tokensPerSec: Float = 0f,
    val totalTokens: Int = 0,
    val draftWindowSize: Int = 0,
    val acceptanceRate: Float = 0f,
    val rttMs: Float = 0f,
    val fallbackMode: Boolean = false
)
