package com.devicellm.chat.engine

import com.devicellm.chat.speculative.SpeculativeDecoderGrpcKt
import com.devicellm.chat.speculative.VerifyRequest
import com.devicellm.chat.speculative.VerifyResponse
import io.grpc.ManagedChannelBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

class GrpcVerifier(host: String = "10.0.2.2", port: Int = 50051) {
    private var channel = ManagedChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build()

    private var stub = SpeculativeDecoderGrpcKt.SpeculativeDecoderCoroutineStub(channel)

    fun updateServerMetrics(newHost: String, newPort: Int) {
        channel.shutdownNow()
        channel = ManagedChannelBuilder.forAddress(newHost, newPort)
            .usePlaintext()
            .build()
        stub = SpeculativeDecoderGrpcKt.SpeculativeDecoderCoroutineStub(channel)
    }

    suspend fun verifyDraft(
        prompt: String,
        draftTokens: List<Int>,
        rttMs: Float
    ): VerifyResponse? = withContext(Dispatchers.IO) {
        try {
            val request = VerifyRequest.newBuilder()
                .setSessionId(UUID.randomUUID().toString())
                .setPrompt(prompt)
                .addAllDraftTokenIds(draftTokens)
                .setRttMs(rttMs)
                .build()
            
            stub.verifyDraft(request)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun shutdown() {
        channel.shutdown()
    }
}
