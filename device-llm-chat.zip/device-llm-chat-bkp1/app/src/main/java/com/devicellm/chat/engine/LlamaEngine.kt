package com.devicellm.chat.engine

import com.devicellm.chat.domain.GenerationMetrics

class LlamaEngine {
    companion object {
        init {
            System.loadLibrary("devicellmchat")
        }
    }

    private external fun loadModelJNI(path: String, contextSize: Int, threadCount: Int, useNnapi: Boolean): Boolean
    private external fun generateJNI(prompt: String, callback: (String) -> Unit, maxTokens: Int, temperature: Float, topP: Float): FloatArray?
    private external fun stopGenerationJNI()
    private external fun freeModelJNI()

    fun loadModel(modelPath: String, contextSize: Int = 1024, threadCount: Int = 4, useNnapi: Boolean = false): Boolean {
        return loadModelJNI(modelPath, contextSize, threadCount, useNnapi)
    }

    /**
     * Synchronous generation call; callback invoked on caller thread or JNI thread
     */
    fun generate(
        prompt: String,
        maxTokens: Int = 512,
        temperature: Float = 0.7f,
        topP: Float = 0.9f,
        onToken: (String) -> Unit
    ): GenerationMetrics? {
        val result = generateJNI(prompt, { token -> onToken(token) }, maxTokens, temperature, topP)
        return result?.let {
            GenerationMetrics(
                ttftMs = it[0],
                totalTimeMs = it[1],
                tokensPerSec = it[2],
                totalTokens = it[3].toInt()
            )
        }
    }

    fun stop() {
        stopGenerationJNI()
    }

    fun free() {
        freeModelJNI()
    }
}
