import React, { useState, useEffect, useMemo } from 'react';
import { 
  Activity, 
  Cpu, 
  Zap, 
  ShieldAlert, 
  BarChart3, 
  Layers, 
  Terminal, 
  Settings,
  RefreshCw,
  Database,
  Smartphone,
  Server as ServerIcon,
  ChevronRight,
  CheckCircle2,
  XCircle
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart, 
  Area,
  BarChart,
  Bar
} from 'recharts';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// --- Utility ---
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Mock Data Generator ---
const generateMetrics = (count: number) => {
  return Array.from({ length: count }).map((_, i) => ({
    time: i,
    acceptance: 0.6 + Math.random() * 0.35,
    latency: 30 + Math.random() * 60,
    window: Math.floor(4 + Math.random() * 7),
    tokens: Math.floor(100 + Math.random() * 500),
    grpc: Math.floor(Math.random() * 100),
    http: Math.floor(Math.random() * 50)
  }));
};

// --- Components ---

const StatCard = ({ title, value, icon: Icon, trend, color }: any) => (
  <div className="bg-[#151619] border border-[#2A2B2F] p-5 rounded-xl flex flex-col gap-3">
    <div className="flex justify-between items-start">
      <span className="text-[#8E9299] text-xs font-mono uppercase tracking-wider">{title}</span>
      <div className={cn("p-2 rounded-lg", color)}>
        <Icon size={18} />
      </div>
    </div>
    <div className="flex items-baseline gap-2">
      <span className="text-2xl font-mono text-white">{value}</span>
      {trend && (
        <span className={cn("text-[10px] font-mono", trend > 0 ? "text-emerald-400" : "text-rose-400")}>
          {trend > 0 ? '↑' : '↓'}{Math.abs(trend)}%
        </span>
      )}
    </div>
  </div>
);

const CodeBlock = ({ code, language }: { code: string; language: string }) => (
  <div className="bg-[#0A0A0A] rounded-lg border border-[#2A2B2F] overflow-hidden">
    <div className="bg-[#1A1B1E] px-4 py-2 border-bottom border-[#2A2B2F] flex justify-between items-center">
      <span className="text-[10px] font-mono text-[#8E9299] uppercase">{language}</span>
      <div className="flex gap-1.5">
        <div className="w-2 h-2 rounded-full bg-[#3A3B3F]" />
        <div className="w-2 h-2 rounded-full bg-[#3A3B3F]" />
        <div className="w-2 h-2 rounded-full bg-[#3A3B3F]" />
      </div>
    </div>
    <pre className="p-4 text-xs font-mono text-[#D1D5DB] overflow-x-auto leading-relaxed">
      <code>{code}</code>
    </pre>
  </div>
);

export default function App() {
  const [metrics, setMetrics] = useState(generateMetrics(20));
  const [activeTab, setActiveTab] = useState<'overview' | 'architecture' | 'logs'>('overview');
  const [isSimulating, setIsSimulating] = useState(true);

  useEffect(() => {
    if (!isSimulating) return;
    const interval = setInterval(() => {
      setMetrics(prev => {
        const next = [...prev.slice(1), {
          time: prev[prev.length - 1].time + 1,
          acceptance: 0.65 + Math.random() * 0.3,
          latency: 25 + Math.random() * 50,
          window: Math.floor(5 + Math.random() * 6),
          tokens: Math.floor(150 + Math.random() * 400),
          grpc: Math.floor(Math.random() * 100),
          http: Math.floor(Math.random() * 50)
        }];
        return next;
      });
    }, 3000);
    return () => clearInterval(interval);
  }, [isSimulating]);

  const currentStats = useMemo(() => {
    const last = metrics[metrics.length - 1];
    const total = last.grpc + last.http;
    return {
      acceptance: (last.acceptance * 100).toFixed(1) + '%',
      latency: last.latency.toFixed(0) + 'ms',
      window: last.window,
      throughput: last.tokens + ' t/s',
      grpcPercent: ((last.grpc / total) * 100).toFixed(0) + '%'
    };
  }, [metrics]);

  return (
    <div className="min-h-screen bg-[#0E0F11] text-[#E1E1E1] font-sans selection:bg-emerald-500/30">
      {/* Sidebar Navigation */}
      <div className="fixed left-0 top-0 bottom-0 w-64 border-r border-[#1A1B1E] bg-[#0E0F11] z-50 hidden lg:flex flex-col">
        <div className="p-6 border-b border-[#1A1B1E] flex items-center gap-3">
          <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(16,185,129,0.3)]">
            <Zap size={18} className="text-black fill-current" />
          </div>
          <h1 className="font-mono text-sm font-bold tracking-tighter uppercase">Spec-Engine v1.0</h1>
        </div>
        
        <nav className="flex-1 p-4 space-y-1">
          {[
            { id: 'overview', label: 'Dashboard', icon: Activity },
            { id: 'architecture', label: 'Architecture', icon: Layers },
            { id: 'logs', label: 'System Logs', icon: Terminal },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
                activeTab === item.id 
                  ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" 
                  : "text-[#8E9299] hover:text-white hover:bg-[#1A1B1E]"
              )}
            >
              <item.icon size={18} />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-[#1A1B1E]">
          <div className="bg-[#151619] rounded-xl p-4 border border-[#2A2B2F]">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] font-mono text-[#8E9299] uppercase">System Status</span>
            </div>
            <p className="text-xs text-white font-medium">Llama-3-8B Active</p>
            <div className="mt-3 h-1 w-full bg-[#2A2B2F] rounded-full overflow-hidden">
              <div className="h-full bg-emerald-500 w-[78%]" />
            </div>
            <p className="mt-1.5 text-[10px] font-mono text-[#8E9299]">VRAM: 6.2GB / 8GB</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="lg:pl-64 min-h-screen">
        <header className="h-16 border-b border-[#1A1B1E] bg-[#0E0F11]/80 backdrop-blur-md sticky top-0 z-40 px-8 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-mono text-[#8E9299]">
            <span className="uppercase">Cluster</span>
            <ChevronRight size={12} />
            <span className="text-white">US-EAST-1-GPU-04</span>
          </div>
          
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSimulating(!isSimulating)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-[#1A1B1E] border border-[#2A2B2F] text-[11px] font-mono hover:bg-[#2A2B2F] transition-colors"
            >
              <RefreshCw size={14} className={isSimulating ? "animate-spin" : ""} />
              {isSimulating ? "LIVE FEED" : "PAUSED"}
            </button>
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-emerald-500 to-cyan-500 border border-white/10" />
          </div>
        </header>

        <div className="p-8 max-w-7xl mx-auto">
          {activeTab === 'overview' && (
            <div className="space-y-8">
              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard 
                  title="Acceptance Rate" 
                  value={currentStats.acceptance} 
                  icon={Zap} 
                  trend={4.2}
                  color="bg-emerald-500/10 text-emerald-400"
                />
                <StatCard 
                  title="Avg Latency (RTT)" 
                  value={currentStats.latency} 
                  icon={Activity} 
                  trend={-12.5}
                  color="bg-blue-500/10 text-blue-400"
                />
                <StatCard 
                  title="Draft Window" 
                  value={currentStats.window} 
                  icon={Layers} 
                  color="bg-amber-500/10 text-amber-400"
                />
                <StatCard 
                  title="Throughput" 
                  value={currentStats.throughput} 
                  icon={Cpu} 
                  trend={8.1}
                  color="bg-purple-500/10 text-purple-400"
                />
                <StatCard 
                  title="gRPC Traffic" 
                  value={currentStats.grpcPercent} 
                  icon={Database} 
                  color="bg-cyan-500/10 text-cyan-400"
                />
              </div>

              {/* Charts Section */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-[#151619] border border-[#2A2B2F] rounded-2xl p-6">
                  <div className="flex justify-between items-center mb-6">
                    <div>
                      <h3 className="text-sm font-bold font-mono uppercase tracking-tight">Acceptance Performance</h3>
                      <p className="text-xs text-[#8E9299]">Real-time speculative token verification rate</p>
                    </div>
                    <div className="flex gap-2">
                      <div className="flex items-center gap-1.5">
                        <div className="w-2 h-2 rounded-full bg-emerald-500" />
                        <span className="text-[10px] font-mono text-[#8E9299]">RATE</span>
                      </div>
                    </div>
                  </div>
                  <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={metrics}>
                        <defs>
                          <linearGradient id="colorAcc" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1F2023" vertical={false} />
                        <XAxis 
                          dataKey="time" 
                          stroke="#3A3B3F" 
                          fontSize={10} 
                          tickLine={false} 
                          axisLine={false}
                        />
                        <YAxis 
                          stroke="#3A3B3F" 
                          fontSize={10} 
                          tickLine={false} 
                          axisLine={false}
                          domain={[0, 1]}
                          tickFormatter={(val) => `${(val * 100).toFixed(0)}%`}
                        />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#1A1B1E', border: '1px solid #2A2B2F', borderRadius: '8px', fontSize: '10px' }}
                          itemStyle={{ color: '#10b981' }}
                        />
                        <Area 
                          type="monotone" 
                          dataKey="acceptance" 
                          stroke="#10b981" 
                          strokeWidth={2}
                          fillOpacity={1} 
                          fill="url(#colorAcc)" 
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="bg-[#151619] border border-[#2A2B2F] rounded-2xl p-6">
                  <h3 className="text-sm font-bold font-mono uppercase tracking-tight mb-6">Active Sessions</h3>
                  <div className="space-y-4">
                    {[
                      { id: 'sess_82a', device: 'Android Pixel 8', rate: '92%', status: 'optimal' },
                      { id: 'sess_14f', device: 'Android S24', rate: '78%', status: 'optimal' },
                      { id: 'sess_99k', device: 'Android Pixel 7', rate: '42%', status: 'fallback' },
                      { id: 'sess_33p', device: 'Android Pixel 8', rate: '85%', status: 'optimal' },
                    ].map((session) => (
                      <div key={session.id} className="flex items-center justify-between p-3 rounded-xl bg-[#0E0F11] border border-[#1A1B1E]">
                        <div className="flex items-center gap-3">
                          <div className={cn(
                            "w-8 h-8 rounded-lg flex items-center justify-center",
                            session.status === 'optimal' ? "bg-emerald-500/10 text-emerald-400" : "bg-rose-500/10 text-rose-400"
                          )}>
                            <Smartphone size={16} />
                          </div>
                          <div>
                            <p className="text-[11px] font-bold font-mono">{session.id}</p>
                            <p className="text-[10px] text-[#8E9299]">{session.device}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-[11px] font-mono font-bold">{session.rate}</p>
                          <p className={cn(
                            "text-[9px] uppercase font-mono",
                            session.status === 'optimal' ? "text-emerald-500" : "text-rose-500"
                          )}>{session.status}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                  <button className="w-full mt-6 py-2 rounded-lg border border-[#2A2B2F] text-[10px] font-mono uppercase tracking-widest text-[#8E9299] hover:text-white hover:bg-[#1A1B1E] transition-all">
                    View All Sessions
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'architecture' && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold tracking-tight">System Architecture</h2>
                  <p className="text-[#8E9299] leading-relaxed">
                    A production-grade speculative decoding implementation where the draft model runs remotely on edge devices (Android) while the verifier (Llama 3 8B) runs on high-performance GPU clusters using vLLM.
                  </p>
                  
                  <div className="space-y-4">
                    <div className="flex gap-4">
                      <div className="flex-shrink-0 w-10 h-10 rounded-full bg-[#1A1B1E] border border-[#2A2B2F] flex items-center justify-center text-emerald-400">
                        <Smartphone size={20} />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold">Remote Drafter (Android)</h4>
                        <p className="text-xs text-[#8E9299]">TinyLlama-1B generating K draft tokens per step. Optimized for low-power NPU execution.</p>
                      </div>
                    </div>
                    <div className="flex gap-4">
                      <div className="flex-shrink-0 w-10 h-10 rounded-full bg-[#1A1B1E] border border-[#2A2B2F] flex items-center justify-center text-blue-400">
                        <ServerIcon size={20} />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold">GPU Verifier (vLLM)</h4>
                        <p className="text-xs text-[#8E9299]">Llama-3-8B validating draft tokens in a single forward pass. Continuous batching enabled.</p>
                      </div>
                    </div>
                    <div className="flex gap-4">
                      <div className="flex-shrink-0 w-10 h-10 rounded-full bg-[#1A1B1E] border border-[#2A2B2F] flex items-center justify-center text-amber-400">
                        <Settings size={20} />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold">Adaptive Controller</h4>
                        <p className="text-xs text-[#8E9299]">Dynamically scales draft window (4-10) based on acceptance rate and network RTT.</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xs font-mono uppercase tracking-widest text-[#8E9299]">Core Logic Snippet</h3>
                  <CodeBlock 
                    language="python"
                    code={`# Adaptive Window Scaling Logic
if acc_rate > 0.82:
    session.window_size = min(10, session.window_size + 1)
elif acc_rate < 0.60:
    session.window_size = max(4, session.window_size - 1)

if rtt > 80.0:
    session.window_size = max(4, session.window_size - 1)`}
                  />
                  <CodeBlock 
                    language="python"
                    code={`# Verification Loop
for i in range(len(draft_tokens)):
    top_verifier_token = get_top_token(logits[i])
    if top_verifier_token == draft_tokens[i]:
        accepted.append(draft_tokens[i])
    else:
        accepted.append(top_verifier_token)
        break`}
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'logs' && (
            <div className="bg-[#0A0A0A] border border-[#2A2B2F] rounded-2xl overflow-hidden animate-in fade-in duration-500">
              <div className="bg-[#151619] p-4 border-b border-[#2A2B2F] flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Terminal size={14} className="text-emerald-400" />
                  <span className="text-[10px] font-mono uppercase tracking-widest">System Output</span>
                </div>
                <div className="flex gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500" />
                  <div className="w-2 h-2 rounded-full bg-amber-500" />
                  <div className="w-2 h-2 rounded-full bg-rose-500" />
                </div>
              </div>
              <div className="p-6 font-mono text-[11px] space-y-2 max-h-[600px] overflow-y-auto">
                <p className="text-emerald-400">[INFO] 2024-05-20 14:22:01 - Initializing vLLM Engine...</p>
                <p className="text-[#8E9299]">[INFO] 2024-05-20 14:22:05 - Model meta-llama/Meta-Llama-3-8B loaded successfully.</p>
                <p className="text-[#8E9299]">[INFO] 2024-05-20 14:22:05 - GPU Memory: 6.2GB / 8.0GB allocated.</p>
                <p className="text-blue-400">[DEBUG] 2024-05-20 14:22:10 - Session sess_82a: Request received (RTT: 34ms)</p>
                <p className="text-emerald-400">[SUCCESS] 2024-05-20 14:22:10 - Session sess_82a: Verified 8/8 tokens (100% acceptance)</p>
                <p className="text-[#8E9299]">[INFO] 2024-05-20 14:22:12 - Session sess_82a: Window size increased to 9</p>
                <p className="text-blue-400">[DEBUG] 2024-05-20 14:22:15 - Session sess_99k: Request received (RTT: 92ms)</p>
                <p className="text-amber-400">[WARN] 2024-05-20 14:22:15 - Session sess_99k: Verified 2/8 tokens (25% acceptance)</p>
                <p className="text-rose-400">[ERROR] 2024-05-20 14:22:18 - Session sess_99k: 3 consecutive mismatches. Entering FALLBACK mode.</p>
                <p className="text-[#8E9299]">[INFO] 2024-05-20 14:22:20 - Metrics updated. Global Acceptance: 82.4%</p>
                {Array.from({ length: 20 }).map((_, i) => (
                  <p key={i} className="text-[#3A3B3F] opacity-50">
                    [DEBUG] 2024-05-20 14:22:{25 + i} - Heartbeat US-EAST-1-GPU-04: OK
                  </p>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
