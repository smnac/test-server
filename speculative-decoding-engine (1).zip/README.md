# Speculative Decoding Server (vLLM + Remote Android Drafter)

This project implements a production-grade speculative decoding server designed to work with remote draft models (e.g., TinyLlama 1B running on Android).

## 🏗 Architecture Overview

The system uses a **Verifier-Drafter** architecture:
1. **Drafter (Client-side):** An Android device runs a small model (TinyLlama 1B) to generate a sequence of "speculative" tokens.
2. **Verifier (Server-side):** A high-performance GPU server running **vLLM** with Llama 3 8B. It receives the prompt and the draft tokens, performing a single forward pass to validate them.
3. **Adaptive Controller:** Monitors the acceptance rate and network RTT to dynamically adjust the draft window size (number of tokens the client should speculate).

## 🚀 Getting Started

### Prerequisites
- Python 3.11+
- NVIDIA GPU with 16GB+ VRAM (for Llama 3 8B)
- CUDA 12.1+

### Installation
```bash
pip install -r requirements.txt
```

### GPU Startup Command
To run the server with optimal performance settings for speculative decoding:

```bash
# Set environment variables for vLLM performance
export VLLM_ATTENTION_BACKEND=FLASH_ATTN
export CUDA_VISIBLE_DEVICES=0

# Start the server
python server.py
```

*Note: In production, use `gunicorn` with `uvicorn` workers for better concurrency.*

## 📊 Benchmarking Acceptance Rate

To benchmark the system and find the optimal window size:

1. **Baseline Latency:** Measure the time for a standard `vllm` forward pass without speculation.
2. **Speculative Gain:** Calculate `(Accepted Tokens + 1) / Verifier Pass Time`.
3. **Acceptance Rate (α):** The probability that a draft token is accepted by the verifier.
   - The theoretical speedup is roughly `(1 - α^(K+1)) / (1 - α)`, where K is the window size.
4. **Optimal K:** Use the `/metrics` endpoint to observe how `window_size` scales. If `acceptance_rate` stays above 80%, increase K.

## ☁️ Deployment on Google Cloud (T4 GPU)

Yes, this server is designed for deployment on Google Cloud Platform (GCP). For a T4 GPU instance, we recommend using **Compute Engine** with a Deep Learning VM image or **Google Kubernetes Engine (GKE)**.

### 1. Containerize the Application
Build and push the image to Google Artifact Registry:
```bash
# Authenticate
gcloud auth configure-docker us-central1-docker.pkg.dev

# Build
docker build -t us-central1-docker.pkg.dev/[PROJECT_ID]/spec-engine/server:v1 .

# Push
docker push us-central1-docker.pkg.dev/[PROJECT_ID]/spec-engine/server:v1
```

### 2. Deploy on Compute Engine (GCE)
Create an instance with a T4 GPU:
```bash
gcloud compute instances create spec-decoder-t4 \
    --machine-type=n1-standard-4 \
    --accelerator=type=nvidia-tesla-t4,count=1 \
    --image-family=common-cu121 \
    --image-project=deeplearning-platform-release \
    --maintenance-policy=TERMINATE \
    --metadata="install-nvidia-driver=True"
```

### 3. Deploy on GKE (Recommended for Production)
Use the following resource limits in your manifest:
```yaml
resources:
  limits:
    nvidia.com/gpu: 1
```

## 🛠 Features
- **Dual Protocol Support:** Handles both REST (FastAPI) and gRPC (Android) simultaneously.
- **Adaptive Window Scaling:** Automatically adjusts speculation depth based on real-time performance.
- **Fallback Logic:** Detects repeated mismatches or low acceptance rates and reverts to standard decoding to save compute.
- **Continuous Batching:** Leverages vLLM's PagedAttention for high-throughput verification.
- **Structured Logging:** Detailed system logs for debugging verification mismatches.
