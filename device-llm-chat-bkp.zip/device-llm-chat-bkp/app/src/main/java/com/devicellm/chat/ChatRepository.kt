package com.devicellm.chat

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class ChatRepository(private val context: Context) {
    
    private val engine = LlamaEngine()
    private val _isModelLoaded = MutableStateFlow(false)
    val isModelLoaded: StateFlow<Boolean> = _isModelLoaded.asStateFlow()
    
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()
    
    // Example TinyLlama prompt template
    private val systemPrompt = "<|system|>\nYou are a helpful and honest assistant. Do your best to help the user.</s>\n"
    
    suspend fun loadModelFromAssets(assetName: String, contextSize: Int = 2048, threads: Int = 4): Boolean = withContext(Dispatchers.IO) {
        try {
            val file = File(context.filesDir, assetName)
            if (!file.exists()) {
                context.assets.open(assetName).use { inputStream ->
                    FileOutputStream(file).use { outputStream ->
                        inputStream.copyTo(outputStream)
                    }
                }
            }
            
            val success = engine.loadModel(file.absolutePath, contextSize, threads)
            _isModelLoaded.value = success
            success
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
    
    private fun formatPrompt(history: List<ChatMessage>, newQuery: String): String {
        val builder = java.lang.StringBuilder(systemPrompt)
        
        for (msg in history) {
            if (msg.isUser) {
                builder.append("<|user|>\n${msg.content}</s>\n")
            } else {
                builder.append("<|assistant|>\n${msg.content}</s>\n")
            }
        }
        
        builder.append("<|user|>\n${newQuery}</s>\n<|assistant|>\n")
        return builder.toString()
    }
    
    suspend fun sendMessage(query: String, maxTokens: Int = 1024, temp: Float = 0.7f, onToken: (String) -> Unit) = withContext(Dispatchers.IO) {
        val history = _messages.value
        val prompt = formatPrompt(history, query)
        
        // Appends user message 
        val userMsg = ChatMessage(content = query, isUser = true)
        _messages.value = history + userMsg
        
        // Appends placeholder for assistant message
        var assistantMsg = ChatMessage(content = "", isUser = false)
        _messages.value = _messages.value + assistantMsg
        
        try {
            engine.generate(
                prompt = prompt,
                maxTokens = maxTokens,
                temp = temp,
                topP = 0.9f
            ) { token ->
                assistantMsg = assistantMsg.copy(content = assistantMsg.content + token)
                val currentList = _messages.value.toMutableList()
                currentList[currentList.size - 1] = assistantMsg
                _messages.value = currentList
                
                onToken(token)
            }
        } catch (e: Exception) {
            assistantMsg = assistantMsg.copy(content = "Error generating response.", isError = true)
            val currentList = _messages.value.toMutableList()
            currentList[currentList.size - 1] = assistantMsg
            _messages.value = currentList
        }
    }
    
    fun stopGeneration() {
        engine.stop()
    }
    
    fun clearChat() {
        _messages.value = emptyList()
    }
    
    fun release() {
        engine.release()
    }
}
