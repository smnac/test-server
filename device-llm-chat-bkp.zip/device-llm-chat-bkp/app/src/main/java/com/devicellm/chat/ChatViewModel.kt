package com.devicellm.chat

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ChatRepository(application)
    
    val isModelLoaded = repository.isModelLoaded
    val messages = repository.messages.stateIn(
        viewModelScope, 
        SharingStarted.WhileSubscribed(5000), 
        emptyList()
    )
        
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()
    
    val temperature = MutableStateFlow(0.7f)
    val maxTokens = MutableStateFlow(512)
    val threadCount = MutableStateFlow(4)
    val contextSize = MutableStateFlow(2048)
    
    fun initModel() {
        viewModelScope.launch {
            // By default, assuming a file named tinyllama.gguf exists in assets/
            repository.loadModelFromAssets(
                assetName = "tinyllama.gguf", 
                contextSize = contextSize.value, 
                threads = threadCount.value
            )
        }
    }
    
    fun sendMessage(query: String) {
        if (query.isBlank() || _isGenerating.value) return
        
        viewModelScope.launch {
            _isGenerating.value = true
            repository.sendMessage(query, maxTokens.value, temperature.value) { _ -> 
                // Token streaming callback - UI automatically updates via StateFlow
            }
            _isGenerating.value = false
        }
    }
    
    fun stopGeneration() {
        repository.stopGeneration()
        _isGenerating.value = false
    }
    
    fun clearChat() {
        repository.clearChat()
    }
    
    override fun onCleared() {
        super.onCleared()
        repository.release()
    }
}
