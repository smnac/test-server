package com.devicellm.chat

import android.util.Log

class LlamaEngine {
    
    interface TokenCallback {
        fun onToken(token: String)
    }

    init {
        try {
            System.loadLibrary("devicellmchat")
        } catch (e: UnsatisfiedLinkError) {
            Log.e("LlamaEngine", "Could not load devicellmchat library.", e)
        }
    }
    
    private external fun loadModelJNI(path: String, contextSize: Int, threads: Int): Boolean
    private external fun generateJNI(prompt: String, callback: TokenCallback, maxTokens: Int, temp: Float, topP: Float)
    private external fun stopGenerationJNI()
    private external fun freeModelJNI()
    
    fun loadModel(path: String, contextSize: Int = 2048, threads: Int = 4): Boolean {
        Log.i("LlamaEngine", "Loading model from $path with $threads threads...")
        return loadModelJNI(path, contextSize, threads)
    }
    
    fun generate(
        prompt: String, 
        maxTokens: Int = 512, 
        temp: Float = 0.7f, 
        topP: Float = 0.9f, 
        onToken: (String) -> Unit
    ) {
        val callback = object : TokenCallback {
            override fun onToken(token: String) {
                onToken(token)
            }
        }
        generateJNI(prompt, callback, maxTokens, temp, topP)
    }
    
    fun stop() {
        stopGenerationJNI()
    }
    
    fun release() {
        freeModelJNI()
    }
}
